/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include "AsyncWorkManager.h"

AsyncWorkManager& AsyncWorkManager::GetInstance()
{
    static AsyncWorkManager instance;
    return instance;
}

void AsyncWorkManager::ExecAllAsyncWork()
{
    mutex.lock();
    auto tempList = workList;
    workList.clear();
    mutex.unlock();

    for (auto work : tempList) {
        work.first(work.second);
    }
}

void AsyncWorkManager::ClearAllAsyncWork()
{
    mutex.lock();
    workList.clear();
    mutex.unlock();
}

void AsyncWorkManager::AppendAsyncWork(OHOS::ACELite::AsyncWorkHandler work, void* arg)
{
    mutex.lock();
    workList.push_back(std::make_pair(work, arg));
    mutex.unlock();
}
