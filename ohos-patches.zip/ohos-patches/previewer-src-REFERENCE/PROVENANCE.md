# previewer-src provenance

Verbatim copy of the working tree of /root/OHOS/ide/tools/previewer on the
AuroraGraph build machine (captured by tools/capture-ohos-patches.ps1,
Run 6 T2, 2026-11-18).

- What it is: sources of the OpenHarmony DevEco "rich previewer" host tool
  (Previewer.exe front end: RichPreviewer command loop, JsApp, cli/, util/
  LocalSocket IPC, mock/ virtual screen, jsapp/rich external event loop) as
  used by the AuroraGraph standalone Windows SDK previewer pipeline.
- Upstream: https://gitcode.com/openharmony/ide_previewer (checked out at
  ide/tools/previewer by the pinned manifest_master_260518.xml).
- Base: 4d25197b3f793d5a62beac74f4136e2640412bee (repo HEAD at capture).
- Local modifications: UNCOMMITTED working-tree overlay (47 entries, state
  "superseded-bundle" per Run 7 T1 in ../ohos-state.json). Key changes: RichPreviewer.cpp
  ProcessCommand loop (hot-reload + effect DLL commands), util/windows/
  LocalSocket.cpp + util/unix/LocalSocket.cpp (command pipe transport),
  util/CommandParser.* (new commands), cli/*, jsapp/rich/JsAppImpl.*,
  mock/rich/VirtualScreenImpl.cpp, BUILD.gn/bundle.json for the Windows SDK
  build. Full list: "dirty_files" for ide/tools/previewer in ohos-state.json.
- .git is excluded (it is a symlink into .repo/projects; the base sha above
  is the git anchor).
- Apply: overlay-copy onto a fresh ide/tools/previewer (see ../README.md and
  tools/apply-ohos-patches.ps1); do NOT delete files not present here.