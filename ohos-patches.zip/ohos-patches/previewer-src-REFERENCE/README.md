# previewer-src-REFERENCE (RETIRED overlay - reference only)

This is the Run 6/7 capture of the ide/tools/previewer working tree, kept
ONLY as a historical reference of the pre-separation state.

- It is NOT used for reconstruction. Since Run 8 T4 (2026-11-19) the
  ide_previewer repo is PATCH-BASED: reconstruction applies
  ..\ide_previewer\0001-previewer-bundle-260518.patch (git am --keep-cr)
  like every other repo; tools\apply-ohos-patches.ps1 no longer overlays
  this directory.
- The aurora lineage that once lived here as uncommitted working-tree
  modifications (RichPreviewer ProcessCommand, util/windows/LocalSocket.cpp,
  effects-dir wiring, ...) was classified in Run 8 T2 as already part of the
  260518 previewer bundle - there is no separate "ours" commit for this
  repo (residue EMPTY). See ..\lineage-report.json.
- Do not apply, do not sync, do not delete (provenance).

Authoritative sources: ..\README.md, ..\ohos-state.json (run8_lineage_separation).
Historical details: PROVENANCE.md (written at capture time, pre-Run-8).
