import os
import time
import logging
from dataclasses import dataclass

import paramiko


logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    success: bool
    exit_code: int
    stdout: str
    stderr: str


@dataclass
class BackgroundCommand:
    pid: int
    log_file: str
    exit_code_file: str


class RemoteBuilder:
    def __init__(self, config: dict):
        self.host = config["host"]
        self.port = config["port"]
        self.user = config["user"]
        self.key_path = config.get("key_path")
        self.password = config.get("password")
        self.config = config

    def _get_ssh(self) -> paramiko.SSHClient:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs = {
            "hostname": self.host,
            "port": self.port,
            "username": self.user,
        }

        if self.key_path:
            key_path = os.path.expanduser(self.key_path)
            connect_kwargs["key_filename"] = key_path
        elif self.password:
            connect_kwargs["password"] = self.password
        else:
            raise ValueError("No SSH key or password configured")

        client.connect(**connect_kwargs)
        return client

    def run_command(self, cmd: str, cwd: str = None, timeout: int = 300) -> CommandResult:
        client = self._get_ssh()
        try:
            full_cmd = f"cd {cwd} && {cmd}" if cwd else cmd
            logger.debug(f"SSH: {full_cmd}")
            stdin, stdout, stderr = client.exec_command(full_cmd, timeout=timeout)

            exit_code = stdout.channel.recv_exit_status()
            out = stdout.read().decode("utf-8", errors="replace")
            err = stderr.read().decode("utf-8", errors="replace")

            return CommandResult(
                success=exit_code == 0,
                exit_code=exit_code,
                stdout=out,
                stderr=err,
            )
        finally:
            client.close()

    def start_background(
        self, cmd: str, cwd: str, log_file: str
    ) -> BackgroundCommand:
        exit_code_file = log_file + ".exit_code"
        escaped_cmd = cmd.replace("'", "'\\''")
        full_cmd = (
            f"cd {cwd} && nohup bash -c '{escaped_cmd}; echo $? > {exit_code_file}' "
            f"> {log_file} 2>&1 & echo $!"
        )

        client = self._get_ssh()
        try:
            logger.info(f"Starting background command in {cwd}: {cmd}")
            stdin, stdout, stderr = client.exec_command(full_cmd, timeout=10)
            pid_str = stdout.read().decode("utf-8", errors="replace").strip()
            if not pid_str.isdigit():
                raise RuntimeError(f"Failed to start background command: {pid_str}")
            pid = int(pid_str)
            logger.info(f"Background PID: {pid}, log: {log_file}")
            return BackgroundCommand(
                pid=pid, log_file=log_file, exit_code_file=exit_code_file
            )
        finally:
            client.close()

    def is_process_running(self, pid: int) -> bool:
        result = self.run_command(f"kill -0 {pid} 2>/dev/null; echo $?", timeout=10)
        return result.stdout.strip() == "0"

    def wait_for_completion(
        self,
        bg_cmd: BackgroundCommand,
        poll_interval: int = 60,
        progress_log_interval: int = 10,
    ) -> CommandResult:
        poll_count = 0
        while True:
            if not self.is_process_running(bg_cmd.pid):
                break
            poll_count += 1
            if poll_count % progress_log_interval == 0:
                elapsed_min = (poll_count * poll_interval) / 60
                logger.info(
                    f"PID {bg_cmd.pid} still running "
                    f"({elapsed_min:.0f} min elapsed)..."
                )
            time.sleep(poll_interval)

        exit_code_result = self.run_command(
            f"cat {bg_cmd.exit_code_file}", timeout=10
        )
        try:
            exit_code = int(exit_code_result.stdout.strip())
        except ValueError:
            logger.error(
                f"Could not read exit code from {bg_cmd.exit_code_file}: "
                f"{exit_code_result.stdout}"
            )
            exit_code = -1

        log_tail = self.get_log_tail(bg_cmd.log_file, bytes=10000)

        logger.info(
            f"PID {bg_cmd.pid} completed with exit code {exit_code}"
        )
        return CommandResult(
            success=exit_code == 0,
            exit_code=exit_code,
            stdout=log_tail,
            stderr="",
        )

    def get_log_tail(self, log_file: str, bytes: int = 5000) -> str:
        result = self.run_command(f"tail -c {bytes} {log_file}", timeout=10)
        return result.stdout

    def upload_file(self, local_path: str, remote_path: str):
        client = self._get_ssh()
        try:
            sftp = client.open_sftp()
            logger.info(f"Uploading {local_path} -> {remote_path}")
            sftp.put(str(local_path), remote_path)
            sftp.close()
        finally:
            client.close()

    def read_file(self, remote_path: str) -> str:
        client = self._get_ssh()
        try:
            sftp = client.open_sftp()
            with sftp.open(remote_path, "r") as f:
                content = f.read().decode("utf-8", errors="replace")
            sftp.close()
            return content
        finally:
            client.close()

    def create_dir(self, path: str):
        result = self.run_command(f"mkdir -p {path}")
        if not result.success:
            raise RuntimeError(f"Failed to create directory {path}: {result.stderr}")

    def remove_dir(self, path: str):
        logger.info(f"Removing directory: {path}")
        result = self.run_command(f"rm -rf {path}")
        if not result.success:
            raise RuntimeError(f"Failed to remove directory {path}: {result.stderr}")

    def list_dirs(self, path: str) -> list[str]:
        result = self.run_command(f"ls -1 {path}")
        if not result.success:
            return []
        return [d.strip() for d in result.stdout.splitlines() if d.strip()]

    def check_git_modifications(self, build_path: str) -> bool:
        cmd = (
            "repo forall -j4 -c "
            "'if [ -n \"$(git status --porcelain 2>/dev/null)\" ]; "
            "then echo MODIFIED; fi' 2>/dev/null | head -1"
        )
        result = self.run_command(cmd, cwd=build_path, timeout=120)
        return "MODIFIED" in result.stdout

    def repo_init(self, build_dir: str) -> CommandResult:
        cfg = self.config
        cmd = (
            f"repo init -u {cfg['repo_init_url']} "
            f"-m {build_dir}/manifest.xml "
            f"-b {cfg['repo_init_branch']} "
            f"{cfg.get('repo_init_extra_flags', '')}"
        )
        logger.info(f"repo init in {build_dir}")
        return self.run_command(cmd, cwd=build_dir, timeout=120)

    def repo_sync(self, build_dir: str) -> BackgroundCommand:
        cmd = f"repo sync {self.config.get('sync_flags', '-c -j 24')}"
        log_file = f"{build_dir}/repo_sync.log"
        return self.start_background(cmd, cwd=build_dir, log_file=log_file)

    def run_prebuilts(self, build_dir: str) -> BackgroundCommand:
        cmd = self.config["prebuilts_cmd"]
        log_file = f"{build_dir}/prebuilts.log"
        return self.start_background(cmd, cwd=build_dir, log_file=log_file)

    def run_build(self, build_dir: str) -> BackgroundCommand:
        cfg = self.config
        cmd = (
            f"{cfg['build_script']} "
            f"--abi-type {cfg['build_abi_type']} "
            f"--device-type {cfg['build_device_type']} "
            f"--build-variant {cfg['build_variant']} "
            f"--build-target {cfg['build_target']}"
        )
        extra = cfg.get("build_extra_flags", "").strip()
        if extra:
            cmd += f" {extra}"
        log_file = f"{build_dir}/build.log"
        return self.start_background(cmd, cwd=build_dir, log_file=log_file)
