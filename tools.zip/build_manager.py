import logging
from dataclasses import dataclass


logger = logging.getLogger(__name__)


@dataclass
class BuildInfo:
    name: str
    path: str
    modified: bool


class BuildManager:
    def __init__(self, vm_config: dict, management_config: dict):
        self.builds_root = vm_config["builds_root"]
        self.max_clean_builds = management_config.get("max_clean_builds", 1)

    def list_builds(self, builder) -> list[BuildInfo]:
        dirs = builder.list_dirs(self.builds_root)
        builds = []
        for d in dirs:
            path = f"{self.builds_root}/{d}"
            try:
                modified = builder.check_git_modifications(path)
            except Exception as e:
                logger.warning(f"Could not check modifications for {d}: {e}")
                modified = True
            status = "MODIFIED" if modified else "clean"
            logger.info(f"Build {d}: {status}")
            builds.append(BuildInfo(name=d, path=path, modified=modified))
        return builds

    def get_builds_to_delete(self, builds: list[BuildInfo]) -> list[BuildInfo]:
        clean_builds = sorted(
            [b for b in builds if not b.modified],
            key=lambda b: b.name,
        )
        if len(clean_builds) <= self.max_clean_builds:
            return []
        to_keep = clean_builds[-self.max_clean_builds :]
        to_delete = clean_builds[: -self.max_clean_builds]
        logger.info(
            f"Clean builds to delete: {[b.name for b in to_delete]}, "
            f"keeping: {[b.name for b in to_keep]}"
        )
        return to_delete

    def get_latest_clean_build(self, builds: list[BuildInfo]) -> BuildInfo | None:
        clean = sorted(
            [b for b in builds if not b.modified],
            key=lambda b: b.name,
            reverse=True,
        )
        return clean[0] if clean else None
