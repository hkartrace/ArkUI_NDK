import yaml
from pathlib import Path


PROJECT_ROOT = Path(__file__).parent.resolve()


REQUIRED_KEYS = {
    "ftp": ["host", "user", "password", "base_path", "platform"],
    "extraction": ["seven_zip_path", "download_dir", "manifest_search_path"],
    "vm": [
        "host",
        "port",
        "user",
        "builds_root",
        "repo_init_url",
        "repo_init_branch",
        "sync_flags",
        "prebuilts_cmd",
        "build_script",
        "build_abi_type",
        "build_device_type",
        "build_variant",
        "build_target",
    ],
    "email": ["smtp_host", "smtp_port", "sender", "password", "recipients"],
}


class ConfigError(Exception):
    pass


def load_config(path="config.yaml") -> dict:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"Config file not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    if config is None:
        raise ConfigError("Config file is empty")

    _resolve_paths(config)
    _validate_config(config)
    return config


def _resolve_paths(config: dict):
    paths_to_resolve = [
        ("extraction", "seven_zip_path"),
    ]
    for section, key in paths_to_resolve:
        raw = config[section][key]
        p = Path(raw)
        if not p.is_absolute():
            config[section][key] = str((PROJECT_ROOT / p).resolve())


def _validate_config(config: dict):
    for section, keys in REQUIRED_KEYS.items():
        if section not in config:
            raise ConfigError(f"Missing required section: {section}")
        for key in keys:
            if key not in config[section]:
                raise ConfigError(f"Missing required key: {section}.{key}")
            if config[section][key] is None:
                raise ConfigError(f"Null value for required key: {section}.{key}")

    if not config["vm"].get("key_path") and not config["vm"].get("password"):
        raise ConfigError("vm.key_path or vm.password must be set")

    if not isinstance(config["email"]["recipients"], list) or not config["email"]["recipients"]:
        raise ConfigError("email.recipients must be a non-empty list")

    if not Path(config["extraction"]["seven_zip_path"]).exists():
        raise ConfigError(
            f"7-Zip not found at: {config['extraction']['seven_zip_path']}. "
            f"Place 7z.exe + 7z.dll in tools/ directory."
        )
