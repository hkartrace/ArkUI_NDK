@echo off
setlocal EnableDelayedExpansion

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: This script must be run as Administrator.
    echo  Right-click and select "Run as administrator".
    echo.
    pause
    exit /b 1
)

set "TASK_NAME=OHOS-AutoBuild"
set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "MAIN_PY=%SCRIPT_DIR%\main.py"
set "CONFIG_YAML=%SCRIPT_DIR%\config.yaml"
set "REQUIREMENTS=%SCRIPT_DIR%\requirements.txt"

:menu
cls
echo.
echo   ====================================
echo     OHOS Auto-Build Service Manager
echo   ====================================
echo.
echo     1. Install service
echo     2. Uninstall service
echo     3. Check status
echo     4. Run now
echo     5. Exit
echo.
echo   ====================================
echo.
set /p "choice=  Enter choice: "

if "%choice%"=="1" goto install
if "%choice%"=="2" goto uninstall
if "%choice%"=="3" goto status
if "%choice%"=="4" goto run_now
if "%choice%"=="5" goto end
echo.
echo   Invalid choice.
timeout /t 2 >nul
goto menu

:install
echo.
echo   [1/4] Checking Python...
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo   ERROR: Python not found in PATH.
    goto done
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo   Found: %%v

echo.
echo   [2/4] Installing Python dependencies...
pip install -r "%REQUIREMENTS%"
if %errorlevel% neq 0 (
    echo   ERROR: Failed to install dependencies.
    goto done
)

echo.
echo   [3/4] Removing existing task if present...
schtasks /query /tn "%TASK_NAME%" >nul 2>&1
if %errorlevel% equ 0 (
    schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1
    echo   Removed existing task.
) else (
    echo   No existing task found.
)

echo.
echo   [4/4] Registering scheduled task...
schtasks /create /tn "%TASK_NAME%" /tr "python \"%MAIN_PY%\" \"%CONFIG_YAML%\"" /sc daily /st 01:00 /rl highest /f
if %errorlevel% neq 0 (
    echo   ERROR: Failed to create scheduled task.
    goto done
)

echo.
echo   ========================================
echo     Service installed successfully!
echo     Task: %TASK_NAME%
echo     Schedule: Daily at 01:00 AM
echo     Script:  %MAIN_PY%
echo     Config:  %CONFIG_YAML%
echo   ========================================
goto done

:uninstall
echo.
schtasks /query /tn "%TASK_NAME%" >nul 2>&1
if %errorlevel% neq 0 (
    echo   Task "%TASK_NAME%" is not registered.
    goto done
)
schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1
if %errorlevel% neq 0 (
    echo   ERROR: Failed to remove task.
    goto done
)
echo   Task "%TASK_NAME%" removed successfully.
goto done

:status
echo.
schtasks /query /tn "%TASK_NAME%" >nul 2>&1
if %errorlevel% neq 0 (
    echo   Task "%TASK_NAME%" is NOT registered.
) else (
    echo   Task "%TASK_NAME%" is registered.
    echo.
    schtasks /query /tn "%TASK_NAME%" /v /fo list
)

echo.
echo   ----------------------------------------
set "STATE_FILE=%SCRIPT_DIR%\state.json"
if exist "%STATE_FILE%" (
    echo   Last build state:
    type "%STATE_FILE%"
) else (
    echo   No state.json found (pipeline has never run).
)
echo   ----------------------------------------
goto done

:run_now
echo.
if not exist "%MAIN_PY%" (
    echo   ERROR: main.py not found at %MAIN_PY%
    goto done
)
if not exist "%CONFIG_YAML%" (
    echo   ERROR: config.yaml not found at %CONFIG_YAML%
    goto done
)
echo   Starting pipeline...
echo   ========================================
echo.
python "%MAIN_PY%" "%CONFIG_YAML%"
echo.
echo   ========================================
echo   Pipeline finished with exit code: %errorlevel%
goto done

:done
echo.
pause
goto menu

:end
endlocal
