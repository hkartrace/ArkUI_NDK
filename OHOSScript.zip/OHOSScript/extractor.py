from __future__ import annotations

import subprocess
import shutil
import logging
from pathlib import Path


logger = logging.getLogger(__name__)


class RARExtractor:
    def __init__(self, config: dict):
        self.seven_zip = config["seven_zip_path"]
        self.min_size_bytes = config.get("min_rar_size_mb", 50) * 1024 * 1024
        self.manifest_search_path = config.get(
            "manifest_search_path", "system_component_config/manifest.xml"
        )

    def validate(self, rar_path: str) -> bool:
        if not Path(rar_path).exists():
            logger.error(f"File not found: {rar_path}")
            return False

        file_size = Path(rar_path).stat().st_size
        if file_size < self.min_size_bytes:
            logger.error(
                f"RAR too small: {file_size} bytes "
                f"(minimum {self.min_size_bytes} bytes)"
            )
            return False

        result = subprocess.run(
            [self.seven_zip, "l", rar_path],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            logger.error(f"7z test failed (exit {result.returncode}): {result.stderr}")
            return False

        logger.info("RAR validation passed")
        return True

    def extract(self, rar_path: str, extract_dir: Path) -> bool:
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        extract_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"Extracting {rar_path} to {extract_dir}...")
        result = subprocess.run(
            [self.seven_zip, "x", rar_path, f"-o{extract_dir}", "-y"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            logger.error(f"Extraction failed: {result.stderr}")
            return False

        logger.info("Extraction complete")
        return True

    def find_manifest(self, search_dir: Path) -> Path | None:
        manifests = list(search_dir.rglob(self.manifest_search_path))
        if manifests:
            logger.info(f"Found manifest: {manifests[0]}")
            return manifests[0]

        manifests = list(search_dir.rglob("manifest.xml"))
        if manifests:
            logger.info(f"Found manifest (fallback search): {manifests[0]}")
            return manifests[0]

        logger.error("manifest.xml not found in extracted archive")
        return None

    def extract_and_find_manifest(self, rar_path: str) -> Path | None:
        download_dir = Path(rar_path).parent
        extract_dir = download_dir / "extracted"

        if not self.extract(rar_path, extract_dir):
            return None

        return self.find_manifest(extract_dir)
