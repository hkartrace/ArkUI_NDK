import json
import hashlib
from pathlib import Path
from datetime import datetime


class StateManager:
    def __init__(self, state_file="state.json"):
        self.state_file = Path(state_file)

    def load(self) -> dict:
        if self.state_file.exists():
            try:
                return json.loads(self.state_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def save(self, state: dict):
        self.state_file.write_text(
            json.dumps(state, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def is_same_rar(self, rar_filename: str) -> bool:
        state = self.load()
        return state.get("last_rar_filename") == rar_filename

    def update(self, rar_filename: str, manifest_hash: str, status: str):
        state = {
            "last_rar_filename": rar_filename,
            "last_manifest_hash": manifest_hash,
            "last_run": datetime.now().isoformat(),
            "last_run_status": status,
        }
        self.save(state)

    @staticmethod
    def hash_content(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()
