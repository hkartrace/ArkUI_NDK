import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


logger = logging.getLogger(__name__)


class Notifier:
    def __init__(self, config: dict):
        self.smtp_host = config["smtp_host"]
        self.smtp_port = config["smtp_port"]
        self.use_tls = config.get("use_tls", True)
        self.sender = config["sender"]
        self.password = config["password"]
        self.recipients = config["recipients"]

    def send(self, subject: str, status: str, logs: str = None):
        status_icon = {
            "success": "[OK]",
            "error": "[FAIL]",
            "warning": "[WARN]",
            "info": "[INFO]",
        }
        icon = status_icon.get(status, "[???]")

        msg = MIMEMultipart()
        msg["From"] = self.sender
        msg["To"] = ", ".join(self.recipients)
        msg["Subject"] = f"[OHOS Build] {icon} {subject}"

        body = f"Status: {status.upper()}\n\n"
        if logs:
            body += f"--- Last log output ---\n{logs}"
        msg.attach(MIMEText(body, "plain"))

        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                if self.use_tls:
                    server.starttls()
                server.login(self.sender, self.password)
                server.send_message(msg)
            logger.info(f"Email sent: {subject}")
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
