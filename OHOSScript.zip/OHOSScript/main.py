import logging
import sys
from datetime import datetime
from pathlib import Path

from config_loader import load_config, ConfigError
from ftp_downloader import FTPDownloader
from extractor import RARExtractor
from remote_builder import RemoteBuilder
from build_manager import BuildManager
from notifier import Notifier
from state import StateManager


def setup_logging(config: dict):
    log_dir = Path(config.get("logging", {}).get("log_dir", "logs"))
    log_dir.mkdir(parents=True, exist_ok=True)

    level = getattr(
        logging, config.get("logging", {}).get("level", "INFO").upper(), logging.INFO
    )

    log_file = log_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def main():
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"

    try:
        config = load_config(config_path)
    except ConfigError as e:
        print(f"Config error: {e}")
        sys.exit(1)

    setup_logging(config)
    logger = logging.getLogger("main")
    logger.info("=" * 60)
    logger.info("OHOS Auto-Build Pipeline starting")

    notifier = Notifier(config["email"])
    state = StateManager()
    downloader = FTPDownloader(config["ftp"])
    extractor = RARExtractor(config["extraction"])
    builder = RemoteBuilder(config["vm"])
    manager = BuildManager(config["vm"], config.get("build_management", {}))
    today = datetime.now().strftime("%Y%m%d")

    try:
        logger.info("Step 1: Finding latest RAR on FTP")
        rar_info = downloader.get_latest_rar()
        if rar_info is None:
            logger.warning("No RAR files found on FTP")
            notifier.send("No RAR files found on FTP", "warning")
            return

        logger.info("Step 2: Checking if already processed")
        if state.is_same_rar(rar_info.filename):
            logger.info(f"Same RAR as last run: {rar_info.filename}, skipping")
            notifier.send(
                f"No new firmware since last run ({rar_info.filename})", "info"
            )
            return

        logger.info(f"Step 3: Downloading {rar_info.filename}")
        rar_path = downloader.download(rar_info, config["extraction"]["download_dir"])

        logger.info("Step 4: Validating RAR")
        if not extractor.validate(rar_path):
            logger.error("RAR validation failed")
            notifier.send(
                f"RAR validation failed: {rar_info.filename}", "error"
            )
            return

        logger.info("Step 5: Extracting and finding manifest.xml")
        manifest_path = extractor.extract_and_find_manifest(rar_path)
        if manifest_path is None:
            logger.error("manifest.xml not found in archive")
            notifier.send(
                f"manifest.xml not found in {rar_info.filename}", "error"
            )
            return

        manifest_content = manifest_path.read_text(encoding="utf-8")
        manifest_hash = StateManager.hash_content(manifest_content)
        logger.info(f"Manifest hash: {manifest_hash[:16]}...")

        logger.info("Step 6: Scanning existing builds on VM")
        builds = manager.list_builds(builder)

        logger.info("Step 7: Comparing manifest with latest clean build")
        latest_clean = manager.get_latest_clean_build(builds)
        if latest_clean:
            try:
                remote_manifest = builder.read_file(f"{latest_clean.path}/manifest.xml")
                remote_hash = StateManager.hash_content(remote_manifest)
                logger.info(f"Remote manifest hash: {remote_hash[:16]}...")
                if remote_hash == manifest_hash:
                    logger.info("Same manifest, no rebuild needed")
                    state.update(rar_info.filename, manifest_hash, "skipped_no_changes")
                    notifier.send(
                        f"Same manifest as {latest_clean.name}, no rebuild needed",
                        "info",
                    )
                    return
            except Exception as e:
                logger.warning(f"Could not compare manifests: {e}")

        logger.info("Step 8: Cleaning old builds")
        to_delete = manager.get_builds_to_delete(builds)
        for b in to_delete:
            try:
                builder.remove_dir(b.path)
                logger.info(f"Deleted old build: {b.name}")
            except Exception as e:
                logger.error(f"Failed to delete {b.name}: {e}")

        logger.info(f"Step 9: Creating build directory {today}")
        build_dir = f"{config['vm']['builds_root']}/{today}"
        builder.create_dir(build_dir)
        builder.upload_file(str(manifest_path), f"{build_dir}/manifest.xml")

        logger.info("Step 10: repo init")
        result = builder.repo_init(build_dir)
        if not result.success:
            logger.error(f"repo init failed: {result.stderr}")
            state.update(rar_info.filename, manifest_hash, "failed_repo_init")
            notifier.send(
                f"repo init failed for {today}",
                "error",
                logs=result.stderr,
            )
            return

        logger.info("Step 11: repo sync (this will take a while)")
        bg = builder.repo_sync(build_dir)
        result = builder.wait_for_completion(bg, poll_interval=60)
        if not result.success:
            logger.error(f"repo sync failed (exit {result.exit_code})")
            state.update(rar_info.filename, manifest_hash, "failed_repo_sync")
            notifier.send(
                f"repo sync failed for {today}",
                "error",
                logs=result.stdout,
            )
            return
        logger.info("repo sync completed")

        logger.info("Step 12: Running prebuilts download")
        bg = builder.run_prebuilts(build_dir)
        result = builder.wait_for_completion(bg, poll_interval=60)
        if not result.success:
            logger.error(f"prebuilts failed (exit {result.exit_code})")
            state.update(rar_info.filename, manifest_hash, "failed_prebuilts")
            notifier.send(
                f"prebuilts download failed for {today}",
                "error",
                logs=result.stdout,
            )
            return
        logger.info("prebuilts completed")

        logger.info("Step 13: Running build (this will take hours)")
        bg = builder.run_build(build_dir)
        result = builder.wait_for_completion(bg, poll_interval=60)

        if result.success:
            logger.info(f"Build {today} succeeded!")
            state.update(rar_info.filename, manifest_hash, "success")
            notifier.send(
                f"Build {today} succeeded",
                "success",
                logs=result.stdout,
            )
        else:
            logger.error(f"Build {today} failed (exit {result.exit_code})")
            state.update(rar_info.filename, manifest_hash, "failed_build")
            notifier.send(
                f"Build {today} FAILED",
                "error",
                logs=result.stdout,
            )

    except Exception:
        logger.exception("Pipeline crashed with unhandled exception")
        try:
            notifier.send("Pipeline crashed (unhandled exception)", "error")
        except Exception:
            pass
        sys.exit(1)

    logger.info("Pipeline finished")


if __name__ == "__main__":
    main()
