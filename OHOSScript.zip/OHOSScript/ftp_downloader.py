from __future__ import annotations

import ftplib
import os
import logging
from dataclasses import dataclass


logger = logging.getLogger(__name__)


@dataclass
class RARInfo:
    filename: str
    mtime: str
    size: int


class FTPDownloader:
    def __init__(self, config: dict):
        self.host = config["host"]
        self.user = config["user"]
        self.password = config["password"]
        self.platform_path = f"{config['base_path']}{config['platform']}"

    def _connect(self) -> ftplib.FTP:
        ftp = ftplib.FTP()
        ftp.connect(self.host, timeout=30)
        ftp.login(self.user, self.password)
        return ftp

    def _parse_mdtm(self, mdtm_response: str) -> str:
        parts = mdtm_response.split()
        return parts[-1] if parts else ""

    def list_rar_files(self) -> list[RARInfo]:
        ftp = self._connect()
        try:
            ftp.cwd(self.platform_path)
            filenames = ftp.nlst()
            rar_files = []

            for name in filenames:
                if not name.lower().endswith(".rar"):
                    continue
                try:
                    mdtm = self._parse_mdtm(ftp.sendcmd(f"MDTM {name}"))
                    try:
                        size = ftp.size(name) or 0
                    except ftplib.error_perm:
                        size = 0
                    rar_files.append(RARInfo(filename=name, mtime=mdtm, size=size))
                except ftplib.error_perm:
                    logger.warning(f"Could not get info for: {name}")
                    continue

            return rar_files
        finally:
            ftp.quit()

    def get_latest_rar(self) -> RARInfo | None:
        rar_files = self.list_rar_files()
        if not rar_files:
            return None
        rar_files.sort(key=lambda f: f.mtime, reverse=True)
        logger.info(
            f"Latest RAR: {rar_files[0].filename} "
            f"(mtime={rar_files[0].mtime}, size={rar_files[0].size})"
        )
        return rar_files[0]

    def download(self, rar_info: RARInfo, download_dir: str) -> str:
        os.makedirs(download_dir, exist_ok=True)
        local_path = os.path.join(download_dir, rar_info.filename)

        logger.info(f"Downloading {rar_info.filename} to {local_path}...")

        ftp = self._connect()
        try:
            ftp.cwd(self.platform_path)
            with open(local_path, "wb") as f:
                ftp.retrbinary(f"RETR {rar_info.filename}", f.write, blocksize=8192)
        finally:
            ftp.quit()

        logger.info(f"Download complete: {local_path} ({os.path.getsize(local_path)} bytes)")
        return local_path
